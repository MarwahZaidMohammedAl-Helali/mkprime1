# Deployment Checklist for MKPRIME Website

## Pre-Deployment

### 1. SendGrid Configuration
- [ ] Create SendGrid account at https://sendgrid.com
- [ ] Generate API key with "Mail Send" permissions
- [ ] Update API key in `api/contact-sendgrid.php`
- [ ] Update API key in `api/job-application-sendgrid.php`
- [ ] Update recipient email in `api/contact-sendgrid.php`
- [ ] Update recipient email in `api/job-application-sendgrid.php`

### 2. Content Review
- [ ] Review all English content in `js/content.js`
- [ ] Review all Arabic content in `js/content.js`
- [ ] Verify partner logos are in `images/` folder
- [ ] Verify company logo is in `images/` folder
- [ ] Update social media links in `contact.html` if needed
- [ ] Update phone number in `contact.html` if needed

### 3. Testing Locally (Optional)
- [ ] Test with local PHP server: `php -S localhost:8000`
- [ ] Test language switching
- [ ] Test contact form (with test API key)
- [ ] Test job application form
- [ ] Test on mobile viewport

## Deployment to GoDaddy

### 4. File Upload
- [ ] Log in to GoDaddy hosting account
- [ ] Open File Manager or connect via FTP
- [ ] Navigate to `public_html` directory
- [ ] Upload all files from `godaddyyes/` folder
- [ ] Verify all files uploaded successfully

### 5. File Permissions
- [ ] Set PHP files to 644 permissions
- [ ] Set directories to 755 permissions
- [ ] Set `.htaccess` to 644 permissions
- [ ] Verify `images/` folder is readable

### 6. Domain Configuration
- [ ] Verify domain is pointing to correct directory
- [ ] Check if SSL certificate is installed
- [ ] If SSL is active, uncomment HTTPS redirect in `.htaccess`

## Post-Deployment Testing

### 7. Functionality Testing
- [ ] Visit homepage - verify it loads correctly
- [ ] Test language toggle (EN ↔ AR)
- [ ] Verify RTL layout works in Arabic
- [ ] Test navigation on all pages
- [ ] Test mobile menu (hamburger icon)
- [ ] Verify hero slider is working
- [ ] Test scroll animations

### 8. Form Testing
- [ ] Submit contact form with test data
- [ ] Verify email is received
- [ ] Check email formatting and content
- [ ] Test contact form error handling
- [ ] Submit job application with test CV
- [ ] Verify job application email with attachment
- [ ] Test CV file validation (size and type)
- [ ] Test job application error handling

### 9. Mobile Testing
- [ ] Test on iPhone Safari
- [ ] Test on Android Chrome
- [ ] Test on tablet devices
- [ ] Verify mobile menu works
- [ ] Check form usability on mobile
- [ ] Test country dropdown on mobile

### 10. Browser Testing
- [ ] Test on Chrome (latest)
- [ ] Test on Firefox (latest)
- [ ] Test on Safari (latest)
- [ ] Test on Edge (latest)

### 11. Performance Check
- [ ] Check page load speed
- [ ] Verify images are loading
- [ ] Check for console errors
- [ ] Test with slow 3G connection
- [ ] Verify caching is working

### 12. SEO & Accessibility
- [ ] Verify page titles are correct
- [ ] Check meta descriptions
- [ ] Test with screen reader (optional)
- [ ] Verify alt text on images
- [ ] Check heading hierarchy

## Troubleshooting

### Common Issues

**Forms not submitting:**
- Check SendGrid API key is correct
- Verify PHP error logs in cPanel
- Check CORS headers in `.htaccess`
- Ensure API endpoints are accessible

**Images not loading:**
- Verify file paths are correct
- Check file permissions (644)
- Ensure images are in `images/` folder
- Check for case-sensitive filenames

**Language not switching:**
- Clear browser cache
- Check browser console for errors
- Verify all JS files are loaded
- Check localStorage is enabled

**Mobile menu not working:**
- Check JavaScript console for errors
- Verify all JS files are loaded correctly
- Test on different devices

## Final Steps

### 13. Go Live
- [ ] Announce website launch
- [ ] Monitor email submissions
- [ ] Check analytics (if installed)
- [ ] Monitor error logs for first 24 hours

### 14. Backup
- [ ] Create backup of all files
- [ ] Document any custom configurations
- [ ] Save SendGrid API credentials securely

### 15. Maintenance
- [ ] Set up regular backups
- [ ] Monitor email delivery
- [ ] Update content as needed
- [ ] Keep PHP and server software updated

## Support Contacts

- **Hosting Support**: GoDaddy support
- **Email Service**: SendGrid support
- **Development Team**: [Your contact info]

---

**Deployment Date**: _______________
**Deployed By**: _______________
**Notes**: _______________
