// Navigation Module
class Navigation {
    constructor() {
        this.language = localStorage.getItem('language') || 'en';
        this.isMobileMenuOpen = false;
        this.init();
    }

    init() {
        this.render();
        this.attachEventListeners();
        this.applyLanguage();
    }

    render() {
        const navbar = document.getElementById('navbar');
        if (!navbar) return;

        const t = content[this.language];
        const isRTL = this.language === 'ar';

        navbar.innerHTML = `
            <div class="container">
                <div class="nav-content">
                    <div class="logo">
                        <a href="index.html" style="display: flex; align-items: center; gap: 12px; text-decoration: none; color: inherit;">
                            <img src="images/logo.png" alt="MKPRIME" onerror="this.style.display='none'">
                            <span>MKPRIME</span>
                        </a>
                    </div>
                    
                    <div class="nav-links desktop-nav">
                        <a href="index.html">${t.nav.home}</a>
                        <a href="services.html">${t.nav.services}</a>
                        <a href="careers.html">${t.nav.careers}</a>
                        <a href="contact.html">${t.nav.contact}</a>
                    </div>
                    
                    <button class="lang-toggle desktop-lang">
                        ${this.language === 'ar' ? 'EN' : 'عربي'}
                    </button>

                    <button class="hamburger" aria-label="Toggle menu">
                        <span></span>
                        <span></span>
                        <span></span>
                    </button>
                </div>
            </div>
        `;

        // Render mobile menu
        const mobileMenu = document.getElementById('mobile-menu');
        if (mobileMenu) {
            mobileMenu.innerHTML = `
                <div class="mobile-menu-header">
                    <h3 class="mobile-menu-title">${this.language === 'ar' ? 'القائمة' : 'Menu'}</h3>
                </div>
                <div class="mobile-nav-links">
                    <a href="index.html">${t.nav.home}</a>
                    <a href="services.html">${t.nav.services}</a>
                    <a href="careers.html">${t.nav.careers}</a>
                    <a href="contact.html">${t.nav.contact}</a>
                    <button class="lang-toggle mobile-lang">
                        ${this.language === 'ar' ? 'English' : 'العربية'}
                    </button>
                </div>
            `;
        }
    }

    attachEventListeners() {
        // Language toggle buttons
        document.querySelectorAll('.lang-toggle').forEach(btn => {
            btn.addEventListener('click', () => this.toggleLanguage());
        });

        // Hamburger menu
        const hamburger = document.querySelector('.hamburger');
        if (hamburger) {
            hamburger.addEventListener('click', () => this.toggleMobileMenu());
        }

        // Mobile menu overlay
        const overlay = document.getElementById('mobile-overlay');
        if (overlay) {
            overlay.addEventListener('click', () => this.closeMobileMenu());
        }

        // Close mobile menu when clicking nav links
        document.querySelectorAll('.mobile-nav-links a').forEach(link => {
            link.addEventListener('click', () => this.closeMobileMenu());
        });
    }

    toggleLanguage() {
        this.language = this.language === 'ar' ? 'en' : 'ar';
        localStorage.setItem('language', this.language);
        this.applyLanguage();
        this.render();
        
        // Trigger custom event for other components to update
        window.dispatchEvent(new CustomEvent('languageChanged', { detail: { language: this.language } }));
    }

    applyLanguage() {
        const isRTL = this.language === 'ar';
        document.documentElement.lang = this.language;
        document.documentElement.dir = isRTL ? 'rtl' : 'ltr';
    }

    toggleMobileMenu() {
        this.isMobileMenuOpen = !this.isMobileMenuOpen;
        const hamburger = document.querySelector('.hamburger');
        const mobileMenu = document.getElementById('mobile-menu');
        const overlay = document.getElementById('mobile-overlay');

        if (this.isMobileMenuOpen) {
            hamburger?.classList.add('active');
            mobileMenu?.classList.add('mobile-open');
            overlay?.classList.add('active');
        } else {
            hamburger?.classList.remove('active');
            mobileMenu?.classList.remove('mobile-open');
            overlay?.classList.remove('active');
        }
    }

    closeMobileMenu() {
        this.isMobileMenuOpen = false;
        document.querySelector('.hamburger')?.classList.remove('active');
        document.getElementById('mobile-menu')?.classList.remove('mobile-open');
        document.getElementById('mobile-overlay')?.classList.remove('active');
    }
}
