// Forms Module
class ContactForm {
    constructor() {
        this.form = document.getElementById('contact-form');
        this.language = localStorage.getItem('language') || 'en';
        this.detectedCountry = { iso: 'QA', name: 'Qatar' };
        if (this.form) {
            this.init();
        }
    }

    init() {
        this.setupCountryDropdown();
        this.detectCountry();
        this.form.addEventListener('submit', (e) => this.handleSubmit(e));
        
        // Listen for language changes
        window.addEventListener('languageChanged', (e) => {
            this.language = e.detail.language;
            this.updateFormLabels();
        });
    }

    setupCountryDropdown() {
        const dropdownBtn = document.querySelector('.country-button');
        const searchInput = document.querySelector('.country-search');
        
        if (dropdownBtn) {
            dropdownBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                const dropdown = document.querySelector('.country-list');
                dropdown?.classList.toggle('show');
            });
        }

        if (searchInput) {
            searchInput.addEventListener('input', (e) => this.filterCountries(e.target.value));
            searchInput.addEventListener('click', (e) => e.stopPropagation());
        }

        // Close dropdown when clicking outside
        document.addEventListener('click', () => {
            document.querySelector('.country-list')?.classList.remove('show');
        });

        // Render country options
        this.renderCountryOptions();
    }

    renderCountryOptions() {
        const optionsContainer = document.querySelector('.country-options');
        if (!optionsContainer) return;

        optionsContainer.innerHTML = countries.map(country => `
            <div class="country-option" data-code="${country.code}">
                <img src="https://flagcdn.com/w40/${country.iso.toLowerCase()}.png" 
                     alt="${country.name}" class="flag-img-small">
                <span>${this.language === 'ar' ? country.nameAr : country.name}</span>
                <span class="country-code-text">${country.code}</span>
            </div>
        `).join('');

        // Attach click handlers
        optionsContainer.querySelectorAll('.country-option').forEach(option => {
            option.addEventListener('click', () => this.selectCountry(option.dataset.code));
        });
    }

    filterCountries(searchTerm) {
        const optionsContainer = document.querySelector('.country-options');
        if (!optionsContainer) return;

        const filtered = countries.filter(country =>
            country.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            country.nameAr.includes(searchTerm) ||
            country.code.includes(searchTerm)
        );

        optionsContainer.innerHTML = filtered.map(country => `
            <div class="country-option" data-code="${country.code}">
                <img src="https://flagcdn.com/w40/${country.iso.toLowerCase()}.png" 
                     alt="${country.name}" class="flag-img-small">
                <span>${this.language === 'ar' ? country.nameAr : country.name}</span>
                <span class="country-code-text">${country.code}</span>
            </div>
        `).join('');

        optionsContainer.querySelectorAll('.country-option').forEach(option => {
            option.addEventListener('click', () => this.selectCountry(option.dataset.code));
        });
    }

    selectCountry(code) {
        const country = countries.find(c => c.code === code);
        if (!country) return;

        const dropdownBtn = document.querySelector('.country-button');
        const hiddenInput = document.getElementById('country-code');
        
        if (dropdownBtn) {
            dropdownBtn.innerHTML = `
                <img src="https://flagcdn.com/w40/${country.iso.toLowerCase()}.png" 
                     alt="flag" class="flag-img">
                <span>${country.code}</span>
                <span class="dropdown-arrow">▼</span>
            `;
        }

        if (hiddenInput) {
            hiddenInput.value = country.code;
        }

        document.querySelector('.country-list')?.classList.remove('show');
        document.querySelector('.country-search').value = '';
    }

    async detectCountry() {
        try {
            const res = await fetch('https://ipapi.co/json/');
            if (res.ok) {
                const data = await res.json();
                if (data.country_code) {
                    const match = countries.find(c => c.iso === data.country_code);
                    if (match) {
                        this.selectCountry(match.code);
                        this.detectedCountry = { iso: data.country_code, name: data.country_name || match.name };
                        return;
                    }
                }
            }
        } catch (e) {
            // Try fallback
            try {
                const res = await fetch('https://ipwho.is/');
                if (res.ok) {
                    const data = await res.json();
                    if (data.country_code) {
                        const match = countries.find(c => c.iso === data.country_code);
                        if (match) {
                            this.selectCountry(match.code);
                            this.detectedCountry = { iso: data.country_code, name: data.country || match.name };
                        }
                    }
                }
            } catch (e) {
                // Keep default Qatar
            }
        }
    }

    async handleSubmit(e) {
        e.preventDefault();
        
        const formData = new FormData(this.form);
        const countryCode = document.getElementById('country-code').value;
        const phone = formData.get('phone');
        
        const data = {
            name: formData.get('name'),
            email: formData.get('email'),
            phone: `${countryCode} ${phone}`,
            message: formData.get('message'),
            visitorCountry: this.detectedCountry.name,
            visitorCountryCode: this.detectedCountry.iso
        };

        this.setStatus('sending');

        try {
            const response = await fetch('api/contact-sendgrid.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data)
            });

            const result = await response.json();

            if (response.ok && result.success) {
                this.setStatus('success');
                this.form.reset();
                this.selectCountry('+974');
                setTimeout(() => this.setStatus(''), 5000);
            } else {
                this.setStatus('error');
            }
        } catch (error) {
            console.error('Error:', error);
            this.setStatus('error');
        }
    }

    setStatus(status) {
        const submitBtn = this.form.querySelector('.submit-button');
        const alertDiv = this.form.querySelector('.message-alert');

        if (status === 'sending') {
            submitBtn.disabled = true;
            submitBtn.textContent = this.language === 'ar' ? 'جاري الإرسال...' : 'Sending...';
            if (alertDiv) alertDiv.remove();
        } else if (status === 'success') {
            submitBtn.disabled = false;
            submitBtn.textContent = content[this.language].contact.send;
            this.showAlert('success', this.language === 'ar' ? '✓ تم إرسال رسالتك بنجاح!' : '✓ Message sent successfully!');
        } else if (status === 'error') {
            submitBtn.disabled = false;
            submitBtn.textContent = content[this.language].contact.send;
            this.showAlert('error', this.language === 'ar' ? '✗ حدث خطأ. يرجى المحاولة مرة أخرى.' : '✗ An error occurred. Please try again.');
        } else {
            submitBtn.disabled = false;
            submitBtn.textContent = content[this.language].contact.send;
            if (alertDiv) alertDiv.remove();
        }
    }

    showAlert(type, message) {
        const existingAlert = this.form.querySelector('.message-alert');
        if (existingAlert) existingAlert.remove();

        const alert = document.createElement('div');
        alert.className = `message-alert ${type}`;
        alert.textContent = message;
        this.form.appendChild(alert);
    }

    updateFormLabels() {
        // Update form labels when language changes
        this.renderCountryOptions();
    }
}

class JobApplicationForm {
    constructor() {
        this.form = document.getElementById('job-application-form');
        this.language = localStorage.getItem('language') || 'en';
        this.detectedCountry = { iso: 'QA', name: 'Qatar' };
        if (this.form) {
            this.init();
        }
    }

    init() {
        this.setupCountryDropdown();
        this.detectCountry();
        this.form.addEventListener('submit', (e) => this.handleSubmit(e));
        
        const fileInput = document.getElementById('cv-upload');
        if (fileInput) {
            fileInput.addEventListener('change', (e) => this.validateFile(e.target.files[0]));
        }

        window.addEventListener('languageChanged', (e) => {
            this.language = e.detail.language;
        });
    }

    setupCountryDropdown() {
        const dropdownBtn = document.querySelector('.country-button');
        const searchInput = document.querySelector('.country-search');
        
        if (dropdownBtn) {
            dropdownBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                const dropdown = document.querySelector('.country-list');
                dropdown?.classList.toggle('show');
            });
        }

        if (searchInput) {
            searchInput.addEventListener('input', (e) => this.filterCountries(e.target.value));
            searchInput.addEventListener('click', (e) => e.stopPropagation());
        }

        document.addEventListener('click', () => {
            document.querySelector('.country-list')?.classList.remove('show');
        });

        this.renderCountryOptions();
    }

    renderCountryOptions() {
        const optionsContainer = document.querySelector('.country-options');
        if (!optionsContainer) return;

        optionsContainer.innerHTML = countries.map(country => `
            <div class="country-option" data-code="${country.code}">
                <img src="https://flagcdn.com/w40/${country.iso.toLowerCase()}.png" 
                     alt="${country.name}" class="flag-img-small">
                <span>${this.language === 'ar' ? country.nameAr : country.name}</span>
                <span class="country-code-text">${country.code}</span>
            </div>
        `).join('');

        optionsContainer.querySelectorAll('.country-option').forEach(option => {
            option.addEventListener('click', () => this.selectCountry(option.dataset.code));
        });
    }

    filterCountries(searchTerm) {
        const optionsContainer = document.querySelector('.country-options');
        if (!optionsContainer) return;

        const filtered = countries.filter(country =>
            country.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            country.nameAr.includes(searchTerm) ||
            country.code.includes(searchTerm)
        );

        optionsContainer.innerHTML = filtered.map(country => `
            <div class="country-option" data-code="${country.code}">
                <img src="https://flagcdn.com/w40/${country.iso.toLowerCase()}.png" 
                     alt="${country.name}" class="flag-img-small">
                <span>${this.language === 'ar' ? country.nameAr : country.name}</span>
                <span class="country-code-text">${country.code}</span>
            </div>
        `).join('');

        optionsContainer.querySelectorAll('.country-option').forEach(option => {
            option.addEventListener('click', () => this.selectCountry(option.dataset.code));
        });
    }

    selectCountry(code) {
        const country = countries.find(c => c.code === code);
        if (!country) return;

        const dropdownBtn = document.querySelector('.country-button');
        const hiddenInput = document.getElementById('country-code');
        
        if (dropdownBtn) {
            dropdownBtn.innerHTML = `
                <img src="https://flagcdn.com/w40/${country.iso.toLowerCase()}.png" 
                     alt="flag" class="flag-img">
                <span>${country.code}</span>
                <span class="dropdown-arrow">▼</span>
            `;
        }

        if (hiddenInput) {
            hiddenInput.value = country.code;
        }

        document.querySelector('.country-list')?.classList.remove('show');
        document.querySelector('.country-search').value = '';
    }

    async detectCountry() {
        try {
            const res = await fetch('https://ipapi.co/json/');
            if (res.ok) {
                const data = await res.json();
                if (data.country_code) {
                    const match = countries.find(c => c.iso === data.country_code);
                    if (match) {
                        this.selectCountry(match.code);
                        this.detectedCountry = { iso: data.country_code, name: data.country_name || match.name };
                        
                        const currentCountryInput = document.getElementById('current-country');
                        if (currentCountryInput && !currentCountryInput.value) {
                            currentCountryInput.value = this.language === 'ar' ? match.nameAr : match.name;
                        }
                        return;
                    }
                }
            }
        } catch (e) {
            // Keep default
        }
    }

    validateFile(file) {
        if (!file) return false;

        const maxSize = 5 * 1024 * 1024; // 5MB
        const allowedTypes = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];

        if (file.size > maxSize) {
            alert(this.language === 'ar' ? 'حجم الملف كبير جداً. الحد الأقصى 5 ميجابايت' : 'File size too large. Maximum 5MB');
            document.getElementById('cv-upload').value = '';
            return false;
        }

        if (!allowedTypes.includes(file.type)) {
            alert(this.language === 'ar' ? 'نوع الملف غير مدعوم. يرجى رفع PDF أو DOC أو DOCX' : 'File type not supported. Please upload PDF, DOC, or DOCX');
            document.getElementById('cv-upload').value = '';
            return false;
        }

        return true;
    }

    async handleSubmit(e) {
        e.preventDefault();
        
        const formData = new FormData(this.form);
        const countryCode = document.getElementById('country-code').value;
        const phone = formData.get('phone');
        const cvFile = document.getElementById('cv-upload').files[0];

        if (!this.validateFile(cvFile)) {
            return;
        }

        const submitData = new FormData();
        submitData.append('name', formData.get('name'));
        submitData.append('nationality', formData.get('nationality'));
        submitData.append('currentCountry', formData.get('currentCountry'));
        submitData.append('email', formData.get('email'));
        submitData.append('phone', `${countryCode} ${phone}`);
        submitData.append('whyHireYou', formData.get('whyHireYou'));
        submitData.append('jobPosition', formData.get('jobPosition') || 'General Application');
        submitData.append('detectedCountry', this.detectedCountry.name);
        submitData.append('detectedCountryCode', this.detectedCountry.iso);
        if (cvFile) {
            submitData.append('cv', cvFile);
        }

        this.setStatus('sending');

        try {
            const response = await fetch('api/job-application-sendgrid.php', {
                method: 'POST',
                body: submitData
            });

            const result = await response.json();

            if (response.ok && result.success) {
                this.setStatus('success');
                this.form.reset();
                this.selectCountry('+974');
                setTimeout(() => {
                    window.location.href = 'careers.html';
                }, 3000);
            } else {
                this.setStatus('error');
            }
        } catch (error) {
            console.error('Error:', error);
            this.setStatus('error');
        }
    }

    setStatus(status) {
        const submitBtn = this.form.querySelector('.submit-button');
        const alertDiv = this.form.querySelector('.message-alert');

        if (status === 'sending') {
            submitBtn.disabled = true;
            submitBtn.textContent = this.language === 'ar' ? 'جاري الإرسال...' : 'Sending...';
            if (alertDiv) alertDiv.remove();
        } else if (status === 'success') {
            submitBtn.disabled = false;
            submitBtn.textContent = content[this.language].jobApplication.submit;
            this.showAlert('success', this.language === 'ar' ? '✓ تم إرسال طلبك بنجاح! سنتواصل معك قريباً.' : '✓ Application submitted successfully! We will contact you soon.');
        } else if (status === 'error') {
            submitBtn.disabled = false;
            submitBtn.textContent = content[this.language].jobApplication.submit;
            this.showAlert('error', this.language === 'ar' ? '✗ حدث خطأ. يرجى المحاولة مرة أخرى.' : '✗ An error occurred. Please try again.');
        } else {
            submitBtn.disabled = false;
            submitBtn.textContent = content[this.language].jobApplication.submit;
            if (alertDiv) alertDiv.remove();
        }
    }

    showAlert(type, message) {
        const existingAlert = this.form.querySelector('.message-alert');
        if (existingAlert) existingAlert.remove();

        const alert = document.createElement('div');
        alert.className = `message-alert ${type}`;
        alert.textContent = message;
        this.form.appendChild(alert);
    }
}
