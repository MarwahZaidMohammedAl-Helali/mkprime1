// Animations Module
class ScrollAnimations {
    constructor() {
        this.observer = null;
        this.init();
    }

    init() {
        this.setupScrollAnimations();
    }

    setupScrollAnimations() {
        this.observer = new IntersectionObserver(
            (entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('visible');
                        this.observer.unobserve(entry.target);
                    }
                });
            },
            {
                threshold: 0.15,
                rootMargin: '0px'
            }
        );

        document.querySelectorAll('.scroll-animate').forEach(el => {
            this.observer.observe(el);
        });
    }

    destroy() {
        if (this.observer) {
            this.observer.disconnect();
        }
    }
}

// Hero Slider
class HeroSlider {
    constructor(images, interval = 5000) {
        this.images = images;
        this.interval = interval;
        this.currentSlide = 0;
        this.timer = null;
        this.init();
    }

    init() {
        this.render();
        this.start();
    }

    render() {
        const sliderContainer = document.querySelector('.slider-container');
        if (!sliderContainer) return;

        sliderContainer.innerHTML = this.images.map((img, index) => `
            <div class="slide ${index === 0 ? 'active' : ''}" style="background-image: url(${img})"></div>
        `).join('');
    }

    start() {
        this.timer = setInterval(() => {
            this.nextSlide();
        }, this.interval);
    }

    nextSlide() {
        const slides = document.querySelectorAll('.slide');
        if (slides.length === 0) return;

        slides[this.currentSlide].classList.remove('active');
        this.currentSlide = (this.currentSlide + 1) % slides.length;
        slides[this.currentSlide].classList.add('active');
    }

    stop() {
        if (this.timer) {
            clearInterval(this.timer);
        }
    }
}
