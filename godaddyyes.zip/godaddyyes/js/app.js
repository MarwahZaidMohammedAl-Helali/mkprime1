// Main Application
class App {
    constructor() {
        this.language = localStorage.getItem('language') || 'en';
        this.navigation = null;
        this.animations = null;
        this.contactForm = null;
        this.jobApplicationForm = null;
        this.heroSlider = null;
        this.init();
    }

    init() {
        // Initialize navigation
        this.navigation = new Navigation();
        
        // Initialize scroll animations
        this.animations = new ScrollAnimations();
        
        // Initialize hero slider if on home page
        const sliderContainer = document.querySelector('.slider-container');
        if (sliderContainer) {
            const heroImages = [
                'https://images.unsplash.com/photo-1523240795612-9a054b0db644?w=1920&q=80',
                'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=1920&q=80',
                'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?w=1920&q=80'
            ];
            this.heroSlider = new HeroSlider(heroImages, 5000);
        }
        
        // Initialize contact form if present
        const contactForm = document.getElementById('contact-form');
        if (contactForm) {
            this.contactForm = new ContactForm();
        }
        
        // Initialize job application form if present
        const jobApplicationForm = document.getElementById('job-application-form');
        if (jobApplicationForm) {
            this.jobApplicationForm = new JobApplicationForm();
        }

        // Update page content with current language
        this.updatePageContent();

        // Listen for language changes
        window.addEventListener('languageChanged', () => {
            this.language = localStorage.getItem('language') || 'en';
            this.updatePageContent();
        });
    }

    updatePageContent() {
        const t = content[this.language];
        
        // Update footer
        const footer = document.getElementById('footer');
        if (footer) {
            footer.innerHTML = `
                <div class="container">
                    <p>${t.footer.tagline}</p>
                    <p>${t.footer.rights}</p>
                </div>
            `;
        }

        // Update page-specific content
        this.updateHomeContent();
        this.updateServicesContent();
        this.updateCareersContent();
        this.updateContactContent();
        this.updateJobApplicationContent();
    }

    updateHomeContent() {
        const heroContent = document.querySelector('.hero-content');
        if (heroContent) {
            const t = content[this.language];
            heroContent.innerHTML = `
                <h1>${t.hero.title}</h1>
                <p>${t.hero.subtitle}</p>
                <a href="contact.html" class="cta-button">${t.hero.cta}</a>
            `;
        }

        const aboutSection = document.querySelector('.about');
        if (aboutSection) {
            const t = content[this.language];
            aboutSection.innerHTML = `
                <div class="container">
                    <h2>${t.about.title}</h2>
                    <div class="about-content">
                        <div class="about-text">
                            <p>${t.about.description}</p>
                            <div class="about-stats">
                                <div class="stat">
                                    <span class="stat-icon">📅</span>
                                    <span>${t.about.founded}</span>
                                </div>
                                <div class="stat">
                                    <span class="stat-icon">👥</span>
                                    <span>${t.about.team}</span>
                                </div>
                                <div class="stat">
                                    <span class="stat-icon">💼</span>
                                    <span>${t.about.type}</span>
                                </div>
                            </div>
                        </div>
                        <div class="about-image">
                            <img src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=600&q=80" alt="Team collaboration">
                        </div>
                    </div>
                </div>
            `;
        }

        const partnersSection = document.querySelector('.partners');
        if (partnersSection) {
            const t = content[this.language];
            const partnersGrid = partnersSection.querySelector('.partners-grid');
            if (partnersGrid) {
                partnersSection.querySelector('h2').textContent = t.partners.title;
                partnersSection.querySelector('.partners-intro').textContent = t.partners.intro;
            }
        }
    }

    updateServicesContent() {
        const servicesSection = document.querySelector('.services');
        if (servicesSection) {
            const t = content[this.language];
            servicesSection.innerHTML = `
                <div class="container">
                    <h2>${t.services.title}</h2>
                    <div class="services-grid">
                        <div class="service-card">
                            <div class="service-icon">
                                <img src="${t.services.service1.image}" alt="${t.services.service1.title}">
                            </div>
                            <h3>${t.services.service1.title}</h3>
                            <p>${t.services.service1.desc}</p>
                        </div>
                        <div class="service-card">
                            <div class="service-icon">
                                <img src="${t.services.service2.image}" alt="${t.services.service2.title}">
                            </div>
                            <h3>${t.services.service2.title}</h3>
                            <p>${t.services.service2.desc}</p>
                        </div>
                        <div class="service-card">
                            <div class="service-icon">
                                <img src="${t.services.service3.image}" alt="${t.services.service3.title}">
                            </div>
                            <h3>${t.services.service3.title}</h3>
                            <p>${t.services.service3.desc}</p>
                        </div>
                        <div class="service-card">
                            <div class="service-icon">
                                <img src="${t.services.service4.image}" alt="${t.services.service4.title}">
                            </div>
                            <h3>${t.services.service4.title}</h3>
                            <p>${t.services.service4.desc}</p>
                        </div>
                    </div>
                </div>
            `;
        }
    }

    updateCareersContent() {
        const careersSection = document.querySelector('.careers');
        if (careersSection) {
            const t = content[this.language];
            const jobsGrid = careersSection.querySelector('.jobs-grid');
            if (jobsGrid) {
                careersSection.querySelector('h2').textContent = t.careers.title;
                careersSection.querySelector('.careers-intro').textContent = t.careers.intro;
                
                jobsGrid.innerHTML = t.careers.jobs.map(job => `
                    <div class="job-card">
                        <h3>${job.title}</h3>
                        <p class="job-type">${job.type}</p>
                        <p>${job.description}</p>
                        <a href="job-application.html?position=${encodeURIComponent(job.title)}" class="apply-button">${t.careers.apply}</a>
                    </div>
                `).join('');
            }
        }
    }

    updateContactContent() {
        const contactSection = document.querySelector('.contact');
        if (contactSection && !document.getElementById('contact-form')) {
            const t = content[this.language];
            const header = contactSection.querySelector('.contact-header');
            if (header) {
                header.innerHTML = `
                    <h2>${t.contact.title}</h2>
                    <p>${t.contact.subtitle}</p>
                `;
            }
        }
    }

    updateJobApplicationContent() {
        const appSection = document.querySelector('.job-application');
        if (appSection && !document.getElementById('job-application-form')) {
            const t = content[this.language];
            const header = appSection.querySelector('.application-header');
            if (header) {
                header.querySelector('h2').textContent = t.jobApplication.title;
                header.querySelector('p').textContent = t.jobApplication.subtitle;
            }
        }
    }
}

// Initialize app when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    new App();
});
