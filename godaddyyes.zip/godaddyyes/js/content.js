// Bilingual Content Data
const content = {
    en: {
        nav: {
            home: 'Home',
            services: 'Services',
            careers: 'Careers',
            contact: 'Contact'
        },
        hero: {
            title: 'Empowering Students Across EA & GCC',
            subtitle: 'Specialized services designed to support your academic journey',
            cta: 'Get in Touch'
        },
        about: {
            title: 'About Us',
            description: 'MKPRIME is dedicated to providing specialized services designed to support students across East Asia (EA) and the Gulf Cooperation Council (GCC) regions. Our offerings are designed to empower students with solutions, including academic services and support, educational technology solutions, and resources that help students efficiently navigate their academic journeys.',
            founded: 'Founded in 2023',
            team: '10-15 Employees',
            type: 'Digital Company'
        },
        services: {
            title: 'Our Services',
            service1: {
                title: 'Academic Support',
                desc: 'Comprehensive support to help students excel in their studies',
                image: 'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?w=400&q=80'
            },
            service2: {
                title: 'Educational Consulting',
                desc: 'Expert guidance for academic planning and career development',
                image: 'https://images.unsplash.com/photo-1552664730-d307ca884978?w=400&q=80'
            },
            service3: {
                title: 'Edu Technology Solutions',
                desc: 'Innovative tech tools and resources for academic success',
                image: 'https://images.unsplash.com/photo-1488190211105-8b0e65b80b4e?w=400&q=80'
            },
            service4: {
                title: 'Quality Education Programs',
                desc: 'We offer programs with a high quality of education and a strong learning system',
                image: 'images/quality-education.jpg'
            }
        },
        careers: {
            title: 'Careers',
            intro: 'Join our team and help us empower students across East Asia and the GCC',
            jobs: [
                {
                    title: 'Assignment Assistant (Remote)',
                    type: 'Part-time',
                    description: 'Assist students with assignments, projects, and coursework while ensuring academic quality and timely submission.'
                },
                {
                    title: 'Student Coordinator (Remote)',
                    type: 'Flexible Hours',
                    description: 'Support students academically and socially while coordinating activities, managing data, and assisting with student engagement.'
                }
            ],
            apply: 'Apply Now'
        },
        partners: {
            title: 'Our Partners',
            intro: 'We are proud to partner with leading institutions to provide the best services to our students'
        },
        contact: {
            title: 'Contact Us',
            subtitle: 'Get in touch with us',
            name: 'Name',
            email: 'Email',
            phone: 'Phone Number',
            message: 'Your Message',
            send: 'Send Message',
            follow_title: 'Follow Us',
            facebook: 'Facebook',
            instagram: 'Instagram'
        },
        footer: {
            tagline: 'Optimizing students\' academic success',
            rights: '© 2026 MKPRIME. All rights reserved.'
        },
        jobApplication: {
            title: 'Job Application',
            subtitle: 'Fill out the form below to apply for a position',
            fullName: 'Full Name',
            nationality: 'Nationality',
            currentCountry: 'Current Country',
            email: 'Email',
            phone: 'Phone Number',
            cv: 'CV / Resume (PDF)',
            whyHireYou: 'Why Should We Hire You?',
            submit: 'Submit Application',
            maxSize: 'Maximum: 5MB',
            sending: 'Sending...',
            success: '✓ Application submitted successfully! We will contact you soon.',
            error: '✗ An error occurred. Please try again.'
        }
    },
    ar: {
        nav: {
            home: 'الرئيسية',
            services: 'خدماتنا',
            careers: 'الوظائف',
            contact: 'اتصل بنا'
        },
        hero: {
            title: 'نمكّن الطلاب في شرق آسيا ودول مجلس التعاون الخليجي',
            subtitle: 'نقدم خدمات متخصصة لدعم الطلاب في رحلتهم الأكاديمية',
            cta: 'تواصل معنا'
        },
        about: {
            title: 'من نحن',
            description: 'نقدّم خدمات مخصصة لدعم الطلاب في الجامعات داخل شرق آسيا والخليج العربي، تشمل: الدعم الأكاديمي - تنظيم الوثائق وإدارتها - حلول تكنولوجيا تعليمية تساعد الطلاب على التكيف والنجاح في بيئة دراستهم. نسعى لتقديم تجربة تعليمية أكثر سلاسة وتنظيماً للطلاب الدوليين.',
            founded: 'تأسست في 2023',
            team: '10-15 موظف',
            type: 'شركة رقمية'
        },
        services: {
            title: 'خدماتنا',
            service1: {
                title: 'الدعم الأكاديمي',
                desc: 'دعم شامل لمساعدة الطلاب على التفوق في دراستهم',
                image: 'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?w=400&q=80'
            },
            service2: {
                title: 'الاستشارات التعليمية',
                desc: 'إرشادات الخبراء للتخطيط الأكاديمي والتطوير الوظيفي',
                image: 'https://images.unsplash.com/photo-1552664730-d307ca884978?w=400&q=80'
            },
            service3: {
                title: 'حلول التكنولوجيا التعليمية',
                desc: 'أدوات وموارد تقنية مبتكرة للنجاح الأكاديمي',
                image: 'https://images.unsplash.com/photo-1488190211105-8b0e65b80b4e?w=400&q=80'
            },
            service4: {
                title: 'برامج تعليمية عالية الجودة',
                desc: 'نقدم برامج ذات جودة تعليمية عالية ونظام تعلم قوي',
                image: 'images/quality-education.jpg'
            }
        },
        careers: {
            title: 'الوظائف',
            intro: 'انضم إلى فريقنا وساعدنا في تمكين الطلاب في جميع أنحاء شرق آسيا ودول مجلس التعاون الخليجي',
            jobs: [
                {
                    title: 'مساعد مهام (عن بعد)',
                    type: 'دوام جزئي',
                    description: 'مساعدة الطلاب في المهام والمشاريع والدورات الدراسية مع ضمان الجودة الأكاديمية والتسليم في الوقت المحدد.'
                },
                {
                    title: 'منسق طلاب (عن بعد)',
                    type: 'ساعات مرنة',
                    description: 'دعم الطلاب أكاديمياً واجتماعياً مع تنسيق الأنشطة وإدارة البيانات والمساعدة في مشاركة الطلاب.'
                }
            ],
            apply: 'تقدم الآن'
        },
        partners: {
            title: 'شركاؤنا',
            intro: 'نفخر بالشراكة مع المؤسسات الرائدة لتقديم أفضل الخدمات لطلابنا'
        },
        contact: {
            title: 'تواصل معنا',
            subtitle: 'تواصل معنا',
            name: 'الاسم',
            email: 'البريد الإلكتروني',
            phone: 'رقم الهاتف',
            message: 'رسالتك',
            send: 'إرسال',
            follow_title: 'تابعنا',
            facebook: 'فيسبوك',
            instagram: 'انستغرام'
        },
        footer: {
            tagline: 'تحسين النجاح الأكاديمي للطلاب',
            rights: '© 2026 MKPRIME. جميع الحقوق محفوظة.'
        },
        jobApplication: {
            title: 'تقديم طلب وظيفة',
            subtitle: 'املأ النموذج أدناه للتقديم على الوظيفة',
            fullName: 'الاسم الكامل',
            nationality: 'الجنسية',
            currentCountry: 'البلد الحالي',
            email: 'البريد الإلكتروني',
            phone: 'رقم الهاتف',
            cv: 'السيرة الذاتية (PDF)',
            whyHireYou: 'لماذا يجب أن نوظفك؟',
            submit: 'إرسال الطلب',
            maxSize: 'الحد الأقصى: 5 ميجابايت',
            sending: 'جاري الإرسال...',
            success: '✓ تم إرسال طلبك بنجاح! سنتواصل معك قريباً.',
            error: '✗ حدث خطأ. يرجى المحاولة مرة أخرى.'
        }
    }
};

// Countries data for phone code selector
const countries = [
    { code: '+93', name: 'Afghanistan', nameAr: 'أفغانستان', iso: 'AF' },
    { code: '+355', name: 'Albania', nameAr: 'ألبانيا', iso: 'AL' },
    { code: '+213', name: 'Algeria', nameAr: 'الجزائر', iso: 'DZ' },
    { code: '+376', name: 'Andorra', nameAr: 'أندورا', iso: 'AD' },
    { code: '+244', name: 'Angola', nameAr: 'أنغولا', iso: 'AO' },
    { code: '+54', name: 'Argentina', nameAr: 'الأرجنتين', iso: 'AR' },
    { code: '+61', name: 'Australia', nameAr: 'أستراليا', iso: 'AU' },
    { code: '+43', name: 'Austria', nameAr: 'النمسا', iso: 'AT' },
    { code: '+973', name: 'Bahrain', nameAr: 'البحرين', iso: 'BH' },
    { code: '+880', name: 'Bangladesh', nameAr: 'بنغلاديش', iso: 'BD' },
    { code: '+32', name: 'Belgium', nameAr: 'بلجيكا', iso: 'BE' },
    { code: '+55', name: 'Brazil', nameAr: 'البرازيل', iso: 'BR' },
    { code: '+1', name: 'Canada', nameAr: 'كندا', iso: 'CA' },
    { code: '+56', name: 'Chile', nameAr: 'تشيلي', iso: 'CL' },
    { code: '+86', name: 'China', nameAr: 'الصين', iso: 'CN' },
    { code: '+57', name: 'Colombia', nameAr: 'كولومبيا', iso: 'CO' },
    { code: '+45', name: 'Denmark', nameAr: 'الدنمارك', iso: 'DK' },
    { code: '+20', name: 'Egypt', nameAr: 'مصر', iso: 'EG' },
    { code: '+33', name: 'France', nameAr: 'فرنسا', iso: 'FR' },
    { code: '+49', name: 'Germany', nameAr: 'ألمانيا', iso: 'DE' },
    { code: '+30', name: 'Greece', nameAr: 'اليونان', iso: 'GR' },
    { code: '+852', name: 'Hong Kong', nameAr: 'هونغ كونغ', iso: 'HK' },
    { code: '+91', name: 'India', nameAr: 'الهند', iso: 'IN' },
    { code: '+62', name: 'Indonesia', nameAr: 'إندونيسيا', iso: 'ID' },
    { code: '+98', name: 'Iran', nameAr: 'إيران', iso: 'IR' },
    { code: '+964', name: 'Iraq', nameAr: 'العراق', iso: 'IQ' },
    { code: '+353', name: 'Ireland', nameAr: 'أيرلندا', iso: 'IE' },
    { code: '+39', name: 'Italy', nameAr: 'إيطاليا', iso: 'IT' },
    { code: '+81', name: 'Japan', nameAr: 'اليابان', iso: 'JP' },
    { code: '+962', name: 'Jordan', nameAr: 'الأردن', iso: 'JO' },
    { code: '+254', name: 'Kenya', nameAr: 'كينيا', iso: 'KE' },
    { code: '+965', name: 'Kuwait', nameAr: 'الكويت', iso: 'KW' },
    { code: '+961', name: 'Lebanon', nameAr: 'لبنان', iso: 'LB' },
    { code: '+60', name: 'Malaysia', nameAr: 'ماليزيا', iso: 'MY' },
    { code: '+52', name: 'Mexico', nameAr: 'المكسيك', iso: 'MX' },
    { code: '+212', name: 'Morocco', nameAr: 'المغرب', iso: 'MA' },
    { code: '+31', name: 'Netherlands', nameAr: 'هولندا', iso: 'NL' },
    { code: '+64', name: 'New Zealand', nameAr: 'نيوزيلندا', iso: 'NZ' },
    { code: '+234', name: 'Nigeria', nameAr: 'نيجيريا', iso: 'NG' },
    { code: '+47', name: 'Norway', nameAr: 'النرويج', iso: 'NO' },
    { code: '+968', name: 'Oman', nameAr: 'عمان', iso: 'OM' },
    { code: '+92', name: 'Pakistan', nameAr: 'باكستان', iso: 'PK' },
    { code: '+970', name: 'Palestine', nameAr: 'فلسطين', iso: 'PS' },
    { code: '+63', name: 'Philippines', nameAr: 'الفلبين', iso: 'PH' },
    { code: '+48', name: 'Poland', nameAr: 'بولندا', iso: 'PL' },
    { code: '+351', name: 'Portugal', nameAr: 'البرتغال', iso: 'PT' },
    { code: '+974', name: 'Qatar', nameAr: 'قطر', iso: 'QA' },
    { code: '+7', name: 'Russia', nameAr: 'روسيا', iso: 'RU' },
    { code: '+966', name: 'Saudi Arabia', nameAr: 'السعودية', iso: 'SA' },
    { code: '+65', name: 'Singapore', nameAr: 'سنغافورة', iso: 'SG' },
    { code: '+27', name: 'South Africa', nameAr: 'جنوب أفريقيا', iso: 'ZA' },
    { code: '+82', name: 'South Korea', nameAr: 'كوريا الجنوبية', iso: 'KR' },
    { code: '+34', name: 'Spain', nameAr: 'إسبانيا', iso: 'ES' },
    { code: '+94', name: 'Sri Lanka', nameAr: 'سريلانكا', iso: 'LK' },
    { code: '+46', name: 'Sweden', nameAr: 'السويد', iso: 'SE' },
    { code: '+41', name: 'Switzerland', nameAr: 'سويسرا', iso: 'CH' },
    { code: '+963', name: 'Syria', nameAr: 'سوريا', iso: 'SY' },
    { code: '+886', name: 'Taiwan', nameAr: 'تايوان', iso: 'TW' },
    { code: '+66', name: 'Thailand', nameAr: 'تايلاند', iso: 'TH' },
    { code: '+90', name: 'Turkey', nameAr: 'تركيا', iso: 'TR' },
    { code: '+971', name: 'UAE', nameAr: 'الإمارات', iso: 'AE' },
    { code: '+44', name: 'United Kingdom', nameAr: 'بريطانيا', iso: 'GB' },
    { code: '+1', name: 'United States', nameAr: 'أمريكا', iso: 'US' },
    { code: '+84', name: 'Vietnam', nameAr: 'فيتنام', iso: 'VN' },
    { code: '+967', name: 'Yemen', nameAr: 'اليمن', iso: 'YE' }
];
