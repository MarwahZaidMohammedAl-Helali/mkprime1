# MKPRIME Website - Plain HTML/CSS/JS Version

This is a plain HTML, CSS, JavaScript, and PHP version of the MKPRIME website, converted from React for easy deployment on standard web hosting platforms like GoDaddy.

## Features

- ✅ Bilingual support (English/Arabic with RTL)
- ✅ Contact form with SendGrid email API
- ✅ Job application form with CV upload
- ✅ Mobile responsive design with hamburger menu
- ✅ Scroll animations
- ✅ Hero image slider
- ✅ Country detection and phone code selector
- ✅ No framework dependencies - pure vanilla JavaScript

## File Structure

```
godaddyyes/
├── index.html              # Home page
├── services.html           # Services page
├── careers.html            # Careers page
├── contact.html            # Contact form page
├── job-application.html    # Job application form
├── 404.html               # Error page
├── .htaccess              # Apache configuration
├── css/
│   ├── main.css           # Main stylesheet
│   └── animations.css     # Scroll animations
├── js/
│   ├── app.js             # Main application logic
│   ├── content.js         # Bilingual content data
│   ├── navigation.js      # Navigation and routing
│   ├── forms.js           # Form handling
│   └── animations.js      # Scroll animations
├── api/
│   ├── contact-sendgrid.php        # Contact form handler
│   └── job-application-sendgrid.php # Job application handler
└── images/
    ├── logo.png
    └── partner images...
```

## Deployment Instructions

### 1. Configure SendGrid API

Before deploying, you need to set up your SendGrid API key:

1. Sign up for a SendGrid account at https://sendgrid.com
2. Create an API key with "Mail Send" permissions
3. Update the API key in both PHP files:
   - `api/contact-sendgrid.php`
   - `api/job-application-sendgrid.php`

Look for this line and replace with your API key:
```php
$sendgridApiKey = 'YOUR_SENDGRID_API_KEY_HERE';
```

### 2. Update Email Recipients

Update the recipient email addresses in the PHP files:

In `api/contact-sendgrid.php`:
```php
$toEmail = 'your-email@example.com';
```

In `api/job-application-sendgrid.php`:
```php
$toEmail = 'hr@example.com';
```

### 3. Upload to GoDaddy

1. Log in to your GoDaddy hosting account
2. Open the File Manager or use FTP
3. Navigate to your public_html directory (or subdirectory)
4. Upload all files from the `godaddyyes` folder
5. Ensure file permissions are correct:
   - PHP files: 644
   - Directories: 755

### 4. Test the Website

1. Visit your domain in a browser
2. Test language switching (English/Arabic)
3. Test the contact form submission
4. Test the job application form with CV upload
5. Test on mobile devices
6. Verify email delivery

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

## Language Persistence

The selected language is stored in the browser's localStorage and persists across page navigations and browser sessions.

## API Endpoints

### Contact Form
- **Endpoint**: `api/contact-sendgrid.php`
- **Method**: POST
- **Content-Type**: application/json
- **Fields**: name, email, phone, message, visitorCountry, visitorCountryCode

### Job Application Form
- **Endpoint**: `api/job-application-sendgrid.php`
- **Method**: POST
- **Content-Type**: multipart/form-data
- **Fields**: name, nationality, currentCountry, email, phone, whyHireYou, jobPosition, cv (file), detectedCountry, detectedCountryCode

## Troubleshooting

### Forms not submitting
- Check that SendGrid API key is correctly configured
- Verify PHP error logs in cPanel
- Ensure CORS headers are enabled in .htaccess

### Images not loading
- Verify image paths are correct
- Check file permissions (should be 644)
- Ensure images are uploaded to the `images/` directory

### Language not switching
- Clear browser cache and localStorage
- Check browser console for JavaScript errors
- Verify all JS files are loaded correctly

### Mobile menu not working
- Check that all JavaScript files are loaded
- Verify there are no JavaScript errors in console
- Test on different mobile devices

## Performance Optimization

The website includes:
- Gzip compression (via .htaccess)
- Browser caching (via .htaccess)
- Optimized images
- Minified CSS (can be further optimized)
- Lazy loading for images

## Security Features

- XSS protection headers
- Content-Type sniffing prevention
- Clickjacking protection
- File upload validation (type and size)
- Input sanitization in PHP

## Support

For issues or questions, contact the development team.

## License

© 2026 MKPRIME. All rights reserved.
